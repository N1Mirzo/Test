<?php
/**
Template Name: LearnDash Courses list
 */
global $THEMEREX_GLOBALS;
$THEMEREX_GLOBALS['blog_filters'] = 'learndash';

get_template_part('blog');
?>