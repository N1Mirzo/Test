<?php
/*
Template Name: Only Reviews
*/

global $THEMEREX_GLOBALS;
$THEMEREX_GLOBALS['blog_filters'] = 'reviews';

get_template_part('blog');
?>