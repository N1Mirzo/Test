<?php
/*
Template Name: BuddyPress page
*/

get_template_part('single');
?>
