<?php
/*
Template Name: LearnDash Course item
*/
get_template_part('single');
?>